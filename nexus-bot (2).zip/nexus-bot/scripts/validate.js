/**
 * Offline sanity check — no Discord connection required.
 * Run with `npm run check`.
 */
import { commands, components, stats } from '../src/commands/index.js';

const SLASH_NAME_RE = /^[-_\p{L}\p{N}]{1,32}$/u;
const OPTION_NAME_RE = /^[-_a-z0-9]{1,32}$/;
const MENU_NAME_RE = /^[\p{L}\p{N} _'-]{1,32}$/u;
const seen = new Map();
let problems = 0;

const fail = (msg) => {
  problems += 1;
  console.error(`  ✗ ${msg}`);
};

console.log('\n─── Command validation ───────────────────────────────────────────');

for (const command of commands) {
  const json = command.data.toJSON();
  const key = `${json.type ?? 1}:${json.name}`;
  if (seen.has(key)) fail(`duplicate command "${json.name}" (type ${json.type ?? 1})`);
  seen.set(key, command);

  const isMenu = json.type === 2 || json.type === 3;
  if (isMenu ? !MENU_NAME_RE.test(json.name) : !SLASH_NAME_RE.test(json.name))
    fail(`invalid name "${json.name}"`);
  if (json.type === undefined || json.type === 1) {
    if (!json.description) fail(`/${json.name} has no description`);
    if (json.description && json.description.length > 100)
      fail(`/${json.name} description is ${json.description.length} chars (max 100)`);
  }
  if (!json.description_localizations && json.description === '') fail(`/${json.name} empty description`);
  if (typeof command.execute !== 'function') fail(`/${json.name} has no execute()`);

  const walk = (options = [], path = '') => {
    // Discord rejects the whole command if a required option follows an optional one.
    let firstOptional = null;
    let sawSubcommand = false;
    let sawPlainOption = false;

    if (options.length > 25) fail(`${path || `/${json.name}`} has ${options.length} options (max 25)`);

    for (const option of options) {
      const where = `${path || `/${json.name}`} → "${option.name}"`;

      if (!OPTION_NAME_RE.test(option.name))
        fail(`${where}: option names must be lowercase a-z 0-9 - _ (got "${option.name}")`);
      if ((option.choices ?? []).length > 25) fail(`${where} has ${option.choices.length} choices (max 25)`);

      if (!option.description) fail(`${where} has no description`);
      if (option.description && option.description.length > 100)
        fail(`${where} description too long (${option.description.length})`);

      // required options must come first
      if (option.required === true && firstOptional !== null) {
        fail(`${where}: required option placed after optional "${firstOptional}" — Discord will reject this command`);
      }
      if (option.required !== true && firstOptional === null) firstOptional = option.name;

      // subcommands and plain options cannot be mixed in one list
      if (option.type === 1 || option.type === 2) sawSubcommand = true;
      else sawPlainOption = true;
      if (sawSubcommand && sawPlainOption) fail(`${path || `/${json.name}`} mixes subcommands with plain options`);

      if (option.options) walk(option.options, `${where}`);
    }
  };
  walk(json.options);

  // a command must also declare at least one option-type that Discord accepts
  const types = new Set((json.options ?? []).map((o) => o.type));
  if (types.has(1) && types.has(2) && (json.options ?? []).every((o) => o.type === 1 || o.type === 2 || o.type === 3)) {
    /* subcommand groups and bare subcommands cannot share a single command */
    const hasBare = (json.options ?? []).some((o) => o.type === 1);
    const hasGroup = (json.options ?? []).some((o) => o.type === 2);
    if (hasBare && hasGroup) fail(`/${json.name} mixes subcommands and subcommand groups`);
  }
}

const chatInput = commands.filter((c) => !c.data.type || c.data.type === 1).length;
const contextMenus = commands.filter((c) => c.data.type === 2 || c.data.type === 3).length;

if (chatInput + contextMenus > 100) {
  fail(`Discord allows at most 100 global commands — you have ${chatInput + contextMenus}. Use GUILD_IDS to register per-server instead.`);
}

console.log(`  ${chatInput} slash commands`);
console.log(`  ${contextMenus} context menu commands`);
console.log(`  ${stats.components} component handlers: ${Object.keys(components).join(', ')}`);

console.log('\n─── Module import check ──────────────────────────────────────────');
console.log('  ✓ every command module imported without throwing');

if (problems) {
  console.error(`\n❌ ${problems} problem(s) found.\n`);
  process.exit(1);
}
console.log('\n✅ All checks passed.\n');
